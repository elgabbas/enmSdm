omnibus::say('Obtaining: Observed distances', post=0)
omnibus::say('| random points', post=0)
omnibus::say('| randomized distances')
